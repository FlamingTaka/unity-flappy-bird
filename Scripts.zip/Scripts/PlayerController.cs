using System.Collections;
using System.Collections.Generic;
using UnityEditor.SearchService;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    Rigidbody2D rb;

    public float jumpForce;
    
    public GameObject loseScreenUI;

    public int score;
    public Text scoreUI;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();        
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        PlayerJump();
    }
    void PlayerJump()
    {
        if (Input.GetMouseButtonDown(0))
        {
            rb.velocity = Vector2.up * jumpForce;
        }
    }

   private void PlayerLose()
    {
        loseScreenUI.SetActive(true);
        Time.timeScale = 0;
    }
    
    public void RestartGame()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void AddScore()
    {
        score++;
        scoreUI.text = score.ToString();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("obstacle"))
        {
            //mati
            PlayerLose();
        }
    }       

    private void OnTriggerEnter2D(Collider2D collision) 
    {
        if (collision.CompareTag("score")) 
        {
            AddScore();
        }
    }
}
